function [ FileList,FileFold,FileFoder,File_num ] = ReadFolder( data,CET,DC_flow,Json )
%READFOLDER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if(Json==1)
     switch data
         case 1
             FileFoder=fullfile('.\pglib-uc-master\ca\');
         case 2
             FileFoder=fullfile('.\pglib-uc-master\ferc\');
         case 3
             FileFoder=fullfile('.\pglib-uc-master\rts_gmlc\');
     end
     dirOutput=dir(fullfile(FileFoder,'*.json'));
     
else
    if(CET==0&&DC_flow==0)
        FileFoder=fullfile('.\UC_AF\');
        if(mod(data,3)==1)
            dirOutput=dir(fullfile(FileFoder,'c*.mod'));
        else
            dirOutput=dir(fullfile(FileFoder,'*w.mod'));
        end
    end
    if(CET==1&&DC_flow==0)
        FileFoder=fullfile('.\CET_data_1\');
        dirOutput=dir(fullfile(FileFoder,'c*.mod'));
    end
    if(CET==0&&DC_flow==1)
        FileFoder=fullfile('.\DC\');
        dirOutput=dir(fullfile(FileFoder,'SCUC*.txt'));
    end
  
end
  FileFold='UC_AF\';
FileList={dirOutput.name}';
File_num=size(FileList,1);



end

