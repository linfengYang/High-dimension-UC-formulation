function [new_model]=obj_linear_general_tangent(model,L,ThPimin,ThPimax,N,T,CET,json,dataUC)
%variable={'uit/oit','B',N*T;'Pit/PitWan','C',N*T;'sit','B',N*T;'Sit/SitWan','C',N*T;'dit','B',N*T;'T3','B',N*T};
variation_num=size(model.ctype,2);
secondary_vari_location=find(diag(model.H)~=0);
secondary_vari_num=N*T;
new_model_variation_num=variation_num+secondary_vari_num;
Aineq=[];
bineq=[];

if(json==0)
    J=0:L;
    for j=1:L+1
        pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',secondary_vari_num,1);
        gradiant=sparse(secondary_vari_num,new_model_variation_num);
        gradiant(1:secondary_vari_num,secondary_vari_location)=sparse(diag(model.H(secondary_vari_location,secondary_vari_location)*(pil)));
        gradiant(1:secondary_vari_num,variation_num+1:new_model_variation_num)=sparse(diag(-1*ones(1,secondary_vari_num)));
        Aineq=[Aineq;gradiant];
        bineq=[bineq;0.5*model.H(secondary_vari_location,secondary_vari_location)*power(pil,2)];
    end
    new_model.lb=[model.lb;-inf*ones(secondary_vari_num,1)];
    new_model.ub=[model.ub;inf*ones(secondary_vari_num,1)];
else
    for i=1:N
        piecewise_production=dataUC.piecewise_production{i};
        L=dataUC.L(i);
        for j=1:L-1
            produce_min=piecewise_production{1, j}.mw;
            produce_max=piecewise_production{1, j+1}.mw;
            produce_cost_min=piecewise_production{1, j}.cost;
            produce_cost_max=piecewise_production{1, j+1}.cost;
            a=(produce_cost_max-produce_cost_min)/(produce_max-produce_min);
            b=produce_cost_max-a*produce_max;
            
            Aineq_piecewise=sparse(T,variation_num+N*T);
%             Aineq_piecewise(1:T,(i-1)*T+1:(i-1)*T+T)=sparse(diag(b*ones(1,T)));
            Aineq_piecewise(1:T,(i-1)*T+N*T+1:(i-1)*T+N*T+T)=sparse(diag(a*ones(1,T)));
            Aineq_piecewise(1:T,(i-1)*T+variation_num+1:(i-1)*T+variation_num+T)=sparse(diag(-1*ones(1,T)));
            Aineq=[Aineq;Aineq_piecewise];
            bineq=[bineq;-1*b*ones(T,1)];
            
        end
    end
    new_model.lb=[model.lb;sparse(secondary_vari_num,1)];
    new_model.ub=[model.ub;inf*ones(secondary_vari_num,1)];
end

new_model.H=[];
new_model.f=[model.f;ones(secondary_vari_num,1)];
new_model.Aineq=[model.Aineq,sparse(size(model.Aineq,1),secondary_vari_num)];
new_model.bineq=model.bineq;
new_model.Aineq=[new_model.Aineq;Aineq];
new_model.bineq=[new_model.bineq;bineq];
new_model.Aeq=[model.Aeq,sparse(size(model.Aeq,1),secondary_vari_num)];
new_model.beq=model.beq;

add_type(1,1:secondary_vari_num)='C';
new_model.ctype=strcat(model.ctype,add_type);
if(CET==1)
    new_model.Q=[model.Q,sparse(size(model.Q,1),secondary_vari_num);sparse(secondary_vari_num,size([model.Q,sparse(size(model.Q,1),secondary_vari_num)],2))];
    new_model.l=[model.l;sparse(secondary_vari_num,1)];
    new_model.r=model.r;
end
end